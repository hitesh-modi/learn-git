This update is for IBM Datacap 9.1.

This update allows zoning of a table area to help identification of a table by the recognition engine.  Refer to the Recognize action help for use of the y_TableZone DCO variable to idnetify the field that has the zone coordinates for the table.

To Install:
1. Close any open Datacap applications and stop any datacap processes.
2. Backup the existing files to a different directory before copying the updated files over the old files.
3. Copy the new files in this zip file over the existing files.